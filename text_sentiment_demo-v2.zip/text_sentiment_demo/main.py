"""
Text Sentiment Demo - Main Application (v2 Enhanced Hackathon Prototype)
Interactive CLI featuring Defensive Input Validation, Multi-Engine Storage (SQLite/JSON/CSV),
Pagination, Automated Test Runner, Log Viewer, and Matplotlib Dashboard Integration.
"""

import datetime
import os
import sys
import unittest
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from sentiment_engine import analyze_sentiment
from storage import (
    load_records_json, save_record_json,
    load_records_csv, save_records_csv,
    SQLiteStorage, sync_all_storages,
    JSON_FILE, CSV_FILE, DB_FILE
)
from analytics import (
    calculate_metrics, search_records, paginate_records,
    generate_executive_report, generate_sentiment_chart
)
from logger import logger, LOG_FILE

# Default active engine: "SQLite" (or "JSON", "CSV")
ACTIVE_STORAGE_ENGINE = "SQLite"
sqlite_db = SQLiteStorage()


def print_banner():
    """Prints a clean branded CLI header."""
    print("=" * 65)
    print("      TEXT SENTIMENT DEMO v2 - AI / NLP APPLICATION      ")
    print("      [Enhanced Grade-A Prototype — Hackathon Edition]   ")
    print("=" * 65)


def get_current_records():
    """Loads records based on the currently selected storage engine."""
    if ACTIVE_STORAGE_ENGINE == "SQLite":
        return sqlite_db.load_records()
    elif ACTIVE_STORAGE_ENGINE == "JSON":
        return load_records_json()
    else:
        return load_records_csv()


def get_validated_input(prompt: str, valid_options: list = None, allow_empty: bool = False) -> str:
    """Centralized defensive input validation helper."""
    while True:
        val = input(prompt).strip()
        if not val and not allow_empty:
            print("⚠️ Input cannot be blank. Please try again.")
            continue
        if valid_options and val not in valid_options:
            print(f"⚠️ Invalid choice. Please select from: {', '.join(valid_options)}")
            continue
        return val


def handle_analyze_new():
    """Menu Handler: Analyze new user text input."""
    print("\n--- Analyze New Text Entry ---")
    text = get_validated_input("Enter text content to evaluate: ")
    
    print("\nSelect Category:")
    print("1. Product Review | 2. Customer Support | 3. Documentation | 4. User Feedback | 5. Error Logs | 6. Other")
    cat_choice = get_validated_input("Choice (1-6): ", ["1", "2", "3", "4", "5", "6"])
    categories = {
        "1": "Product Review", "2": "Customer Support", "3": "Documentation",
        "4": "User Feedback", "5": "Error Logs", "6": "Other"
    }
    category = categories[cat_choice]

    result = analyze_sentiment(text)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    
    existing = get_current_records()
    new_id = max([r.get("id", 0) for r in existing], default=0) + 1

    record = {
        "id": new_id,
        "text": text,
        "category": category,
        "score": result["score"],
        "label": result["label"],
        "confidence": result["confidence"],
        "timestamp": timestamp
    }

    print("\n" + "-" * 50)
    print(f"📊 SENTIMENT EVALUATION RESULT (ID #{new_id})")
    print(f"  Score      : {result['score']:+.2f} (Scale: -1.0 to +1.0)")
    print(f"  Label      : {result['label']}")
    print(f"  Confidence : {int(result['confidence'] * 100)}%")
    if result["positive_words"]:
        print(f"  Positives  : {', '.join(result['positive_words'])}")
    if result["negative_words"]:
        print(f"  Negatives  : {', '.join(result['negative_words'])}")
    if result["phrases_detected"]:
        print(f"  Phrases    : {', '.join(result['phrases_detected'])}")
    print("-" * 50)

    # Save to active engine & sync master
    existing.append(record)
    sync_all_storages(existing)
    print(f"✅ Record #{new_id} saved successfully across {ACTIVE_STORAGE_ENGINE}, JSON, and CSV engines.")


def handle_view_records():
    """Menu Handler: View all records with pagination."""
    records = get_current_records()
    if not records:
        print("\n⚠️ No records found in current storage engine.")
        return

    page = 1
    page_size = 5
    while True:
        page_records, curr_p, total_p = paginate_records(records, page=page, page_size=page_size)
        
        print(f"\n--- Stored Records (Engine: {ACTIVE_STORAGE_ENGINE} | Page {curr_p}/{total_p}) ---")
        print(f"{'ID':<4} | {'Category':<18} | {'Label':<9} | {'Score':<6} | {'Conf':<5} | {'Text'}")
        print("-" * 75)
        for r in page_records:
            short_text = r.get("text", "")[:25] + "..." if len(r.get("text", "")) > 25 else r.get("text", "")
            print(f"{r.get('id'):<4} | {r.get('category'):<18} | {r.get('label'):<9} | {r.get('score'):<+6.2f} | {r.get('confidence'):<5.2f} | {short_text}")
        print("-" * 75)
        
        if total_p == 1:
            input("\nPress Enter to return to main menu...")
            break
            
        nav = get_validated_input("\nNavigation: [N]ext Page | [P]revious Page | [M]ain Menu: ", ["N", "n", "P", "p", "M", "m"])
        if nav.upper() == "N":
            page = min(total_p, page + 1)
        elif nav.upper() == "P":
            page = max(1, page - 1)
        else:
            break


def handle_search():
    """Menu Handler: Search and filter records."""
    records = get_current_records()
    print("\n--- Search & Query Records ---")
    query = get_validated_input("Enter search keyword (or press Enter to skip): ", allow_empty=True)
    
    print("\nFilter by Category:")
    print("0. All | 1. Product Review | 2. Customer Support | 3. Documentation | 4. User Feedback | 5. Error Logs")
    cat_choice = get_validated_input("Choice (0-5): ", ["0", "1", "2", "3", "4", "5"])
    cat_map = {"0": "All", "1": "Product Review", "2": "Customer Support", "3": "Documentation", "4": "User Feedback", "5": "Error Logs"}
    category = cat_map[cat_choice]

    print("\nFilter by Sentiment Label:")
    print("0. All | 1. Positive | 2. Neutral | 3. Negative")
    lbl_choice = get_validated_input("Choice (0-3): ", ["0", "1", "2", "3"])
    lbl_map = {"0": "All", "1": "Positive", "2": "Neutral", "3": "Negative"}
    label = lbl_map[lbl_choice]

    matches = search_records(records, query=query, category=category, label=label)
    print(f"\n🔍 Found {len(matches)} matching records:")
    print(f"{'ID':<4} | {'Category':<18} | {'Label':<9} | {'Score':<6} | {'Text'}")
    print("-" * 70)
    for r in matches:
        short_text = r.get("text", "")[:30] + "..." if len(r.get("text", "")) > 30 else r.get("text", "")
        print(f"{r.get('id'):<4} | {r.get('category'):<18} | {r.get('label'):<9} | {r.get('score'):<+6.2f} | {short_text}")
    print("-" * 70)
    input("\nPress Enter to continue...")


def handle_change_engine():
    """Menu Handler: Switch active storage engine."""
    global ACTIVE_STORAGE_ENGINE
    print(f"\nCurrent Storage Engine: {ACTIVE_STORAGE_ENGINE}")
    print("Select New Storage Engine:")
    print("1. SQLite Database (Recommended for Scalability)")
    print("2. JSON File Storage")
    print("3. CSV Spreadsheet Storage")
    choice = get_validated_input("Choice (1-3): ", ["1", "2", "3"])
    engine_map = {"1": "SQLite", "2": "JSON", "3": "CSV"}
    ACTIVE_STORAGE_ENGINE = engine_map[choice]
    logger.info(f"Switched storage engine to {ACTIVE_STORAGE_ENGINE}")
    print(f"✅ Storage engine changed to {ACTIVE_STORAGE_ENGINE}.")


def handle_analytics():
    """Menu Handler: Generate summary report & visual chart dashboard."""
    records = get_current_records()
    if not records:
        print("\n⚠️ No records available for analytics.")
        return

    metrics = calculate_metrics(records)
    print("\n" + "=" * 55)
    print("         EXECUTIVE SENTIMENT SUMMARY REPORT         ")
    print("=" * 55)
    print(f" Total Feedback Records Analyzed : {metrics['total_records']}")
    print(f" Average Sentiment Score        : {metrics['avg_score']:+.2f} (-1.0 to +1.0)")
    print("-" * 55)
    print(f" Positive Entries                : {metrics['positive_count']:<4} ({metrics['positive_pct']}%)")
    print(f" Neutral Entries                 : {metrics['neutral_count']:<4} ({metrics['neutral_pct']}%)")
    print(f" Negative Entries                : {metrics['negative_count']:<4} ({metrics['negative_pct']}%)")
    print("-" * 55)
    print(" Category Distribution:")
    for cat, count in metrics["categories"].items():
        print(f"   - {cat:<24} : {count} records")
    print("=" * 55)

    # Export report & chart to scratch directory
    report_path = PROJECT_ROOT / "sentiment_summary_report.md"
    chart_path = PROJECT_ROOT / "sentiment_distribution.png"
    
    generate_executive_report(records, report_path)
    chart_created = generate_sentiment_chart(records, chart_path)
    
    print(f"\n📝 Exported Markdown report to: {report_path.name}")
    if chart_created:
        print(f"📊 Exported Visual Dashboard chart to: {chart_path.name}")
    input("\nPress Enter to continue...")


def handle_run_tests():
    """Menu Handler: Execute automated unit test suite."""
    print("\n--- Executing Automated Unit Test Suite ---")
    test_loader = unittest.TestLoader()
    test_suite = test_loader.discover(start_dir=str(PROJECT_ROOT / "tests"), pattern="test_*.py")
    test_runner = unittest.TextTestRunner(verbosity=2)
    result = test_runner.run(test_suite)
    
    if result.wasSuccessful():
        print("\n✅ All Automated Unit Tests Passed (100% Success Rate)!")
    else:
        print(f"\n❌ Test Failures Encountered: {len(result.failures)} failures, {len(result.errors)} errors.")
    input("\nPress Enter to return to menu...")


def handle_view_logs():
    """Menu Handler: View recent system audit logs."""
    print("\n--- System Audit Logs (Recent Entries) ---")
    if not LOG_FILE.exists():
        print("No log file found.")
    else:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines[-20:]:  # Print last 20 log lines
                print(line.strip())
    input("\nPress Enter to return to menu...")


def handle_seed_data():
    """Menu Handler: Seed realistic sample data into storages."""
    sample_file = PROJECT_ROOT / "sample_data.json"
    if not sample_file.exists():
        print("⚠️ Sample data file missing.")
        return

    import json
    with open(sample_file, "r", encoding="utf-8") as f:
        samples = json.load(f)

    sync_all_storages(samples)
    print(f"\n✅ Successfully seeded {len(samples)} sample records across SQLite, JSON, and CSV engines!")
    input("\nPress Enter to continue...")


def main():
    """Main Application Command Dispatch Loop."""
    logger.info("Text Sentiment Demo v2 started.")
    
    # Auto-seed if SQLite DB is empty
    current = get_current_records()
    if not current:
        handle_seed_data()

    while True:
        print_banner()
        print(f"Active Storage Engine: [{ACTIVE_STORAGE_ENGINE}]")
        print("\n1. Analyze New Text & Save Record")
        print("2. View All Stored Records (Paginated)")
        print("3. Search & Filter Records")
        print("4. Switch Storage Engine (SQLite / JSON / CSV)")
        print("5. Generate Executive Analytics & Dashboard")
        print("6. Run Automated Unit Test Suite (Pytest/Unittest)")
        print("7. View System Audit Logs")
        print("8. Seed 30 Sample Data Records")
        print("9. Exit Application")
        
        choice = get_validated_input("\nSelect Option (1-9): ", [str(i) for i in range(1, 10)])
        
        if choice == "1":
            handle_analyze_new()
        elif choice == "2":
            handle_view_records()
        elif choice == "3":
            handle_search()
        elif choice == "4":
            handle_change_engine()
        elif choice == "5":
            handle_analytics()
        elif choice == "6":
            handle_run_tests()
        elif choice == "7":
            handle_view_logs()
        elif choice == "8":
            handle_seed_data()
        elif choice == "9":
            print("\nThank you for using Text Sentiment Demo v2! Exiting...\n")
            logger.info("Application exited cleanly.")
            sys.exit(0)


if __name__ == "__main__":
    main()
