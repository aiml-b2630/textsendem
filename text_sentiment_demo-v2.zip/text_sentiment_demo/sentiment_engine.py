"""
Enhanced NLP Sentiment Engine
Includes bi-gram processing, negation context windows, intensifier scaling,
basic sarcasm heuristic indicators, and stemming fallbacks.
"""

import re
from typing import Dict, List, Any, Tuple
from logger import logger

# Base Unigram Lexicon
UNIGRAM_LEXICON = {
    # Positives
    "good": 0.5, "great": 0.8, "excellent": 0.9, "amazing": 0.9, "awesome": 0.9,
    "fantastic": 0.9, "love": 0.8, "loved": 0.8, "like": 0.4, "liked": 0.4,
    "fast": 0.5, "clean": 0.4, "smooth": 0.5, "easy": 0.5, "helpful": 0.6,
    "perfect": 0.95, "best": 0.85, "happy": 0.7, "satisfied": 0.7, "reliable": 0.7,
    "intuitive": 0.6, "brilliant": 0.85, "superb": 0.9, "impressive": 0.8, "stable": 0.6,

    # Negatives
    "bad": -0.5, "terrible": -0.85, "awful": -0.9, "horrible": -0.9, "slow": -0.5,
    "broken": -0.8, "bug": -0.6, "buggy": -0.7, "crash": -0.8, "crashes": -0.85,
    "hate": -0.8, "hated": -0.8, "poor": -0.6, "worst": -0.9, "useless": -0.85,
    "confusing": -0.5, "frustrating": -0.7, "fail": -0.7, "failed": -0.75, "failure": -0.8,
    "error": -0.5, "difficult": -0.5, "expensive": -0.4, "disappointed": -0.75
}

# Bi-Gram & Phrase Lexicon (Overrides individual words for context accuracy)
BIGRAM_LEXICON = {
    "highly recommend": 0.95,
    "top notch": 0.9,
    "customer service": 0.1,
    "well done": 0.85,
    "easy to use": 0.8,
    "waste of time": -0.9,
    "waste of money": -0.95,
    "total disaster": -0.9,
    "bad experience": -0.8,
    "not working": -0.75,
    "needs work": -0.4,
    "piece of junk": -0.85,
    "out of date": -0.4
}

# Negation Tokens
NEGATION_WORDS = {"not", "no", "never", "n't", "neither", "nor", "hardly", "barely", "scarcely", "lack", "lacks"}

# Intensifiers (Multipliers)
INTENSIFIERS = {
    "very": 1.4,
    "extremely": 1.7,
    "super": 1.5,
    "really": 1.3,
    "highly": 1.4,
    "exceptionally": 1.6,
    "incredibly": 1.6,
    "slightly": 0.6,
    "somewhat": 0.7,
    "barely": 0.5
}

# Sarcasm / Irony Pattern Markers
SARCASM_MARKERS = [
    (r"\boh great\b.*\!", -0.6),
    (r"\bwonderful job breaking\b", -0.8),
    (r"\bthanks a lot for nothing\b", -0.85),
    (r"\bjust what i needed\b.*\!", -0.5)
]


def normalize_token(word: str) -> str:
    """Basic suffix stripping for word normalization."""
    word = word.lower().strip()
    if len(word) > 4:
        if word.endswith("ing"):
            word = word[:-3]
        elif word.endswith("ed"):
            word = word[:-2]
        elif word.endswith("s") and not word.endswith("ss"):
            word = word[:-1]
    return word


def detect_sarcasm(text: str) -> float:
    """Checks for explicit sarcasm heuristics in text."""
    lower_text = text.lower()
    for pattern, penalty in SARCASM_MARKERS:
        if re.search(pattern, lower_text):
            logger.info(f"Sarcasm pattern matched: '{pattern}' in text.")
            return penalty
    return 0.0


def analyze_sentiment(text: str) -> Dict[str, Any]:
    """
    Analyzes input text using unigrams, bi-grams, negations, intensifiers,
    and sarcasm heuristics. Returns score, label, confidence, and tokens.
    """
    if not text or not text.strip():
        logger.warning("Empty text string provided for sentiment analysis.")
        return {
            "score": 0.0,
            "label": "Neutral",
            "confidence": 0.0,
            "positive_words": [],
            "negative_words": [],
            "phrases_detected": [],
            "word_count": 0
        }

    cleaned_text = re.sub(r"[^\w\s\'-]", " ", text.lower())
    tokens = [t for t in cleaned_text.split() if t]
    word_count = len(tokens)
    
    if word_count == 0:
        return {
            "score": 0.0,
            "label": "Neutral",
            "confidence": 0.0,
            "positive_words": [],
            "negative_words": [],
            "phrases_detected": [],
            "word_count": 0
        }

    total_score = 0.0
    matched_positives = []
    matched_negatives = []
    phrases_matched = []

    # Check for sarcasm penalty first
    sarcasm_score = detect_sarcasm(text)
    if sarcasm_score != 0.0:
        total_score += sarcasm_score
        phrases_matched.append("Sarcasm Pattern")

    # 1. Bi-Gram Scanning
    used_token_indices = set()
    for i in range(len(tokens) - 1):
        bigram = f"{tokens[i]} {tokens[i+1]}"
        if bigram in BIGRAM_LEXICON:
            score = BIGRAM_LEXICON[bigram]
            total_score += score
            phrases_matched.append(bigram)
            used_token_indices.add(i)
            used_token_indices.add(i + 1)
            if score > 0:
                matched_positives.append(bigram)
            elif score < 0:
                matched_negatives.append(bigram)

    # 2. Unigram Scanning with Negation & Intensifier Window
    for i, token in enumerate(tokens):
        if i in used_token_indices:
            continue

        raw_word = token
        norm_word = normalize_token(token)

        score = 0.0
        word_found = None

        if raw_word in UNIGRAM_LEXICON:
            score = UNIGRAM_LEXICON[raw_word]
            word_found = raw_word
        elif norm_word in UNIGRAM_LEXICON:
            score = UNIGRAM_LEXICON[norm_word]
            word_found = norm_word

        if score != 0.0:
            # Check preceding 2 tokens for intensifiers and negations
            window = tokens[max(0, i - 2):i]
            is_negated = any(w in NEGATION_WORDS or w.endswith("n't") for w in window)
            
            intensifier_mult = 1.0
            for w in window:
                if w in INTENSIFIERS:
                    intensifier_mult *= INTENSIFIERS[w]

            final_word_score = score * intensifier_mult

            if is_negated:
                # Flip polarity with attenuation
                final_word_score = -0.7 * final_word_score
                word_found = f"not {word_found}"

            total_score += final_word_score

            if final_word_score > 0:
                matched_positives.append(word_found)
            elif final_word_score < 0:
                matched_negatives.append(word_found)

    # Normalize final score between -1.0 and +1.0
    num_matches = len(matched_positives) + len(matched_negatives) + len(phrases_matched)
    if num_matches > 0:
        normalized_score = max(-1.0, min(1.0, total_score / max(1, num_matches * 0.75)))
    else:
        normalized_score = 0.0

    # Determine Categorical Label
    if normalized_score >= 0.15:
        label = "Positive"
    elif normalized_score <= -0.15:
        label = "Negative"
    else:
        label = "Neutral"

    # Compute Confidence Score
    confidence = min(0.99, round(0.40 + (num_matches * 0.15), 2)) if num_matches > 0 else 0.50

    logger.debug(f"Analyzed text: '{text[:30]}...' -> Score: {round(normalized_score, 2)}, Label: {label}")

    return {
        "score": round(normalized_score, 2),
        "label": label,
        "confidence": confidence,
        "positive_words": list(set(matched_positives)),
        "negative_words": list(set(matched_negatives)),
        "phrases_detected": list(set(phrases_matched)),
        "word_count": word_count
    }
