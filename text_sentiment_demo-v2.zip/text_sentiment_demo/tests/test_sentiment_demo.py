"""
Automated Unit Test Suite for Text Sentiment Demo v2
Covers sentiment engine accuracy, negations, bi-grams, storage atomic operations, SQLite, and analytics pagination.
"""

import os
import sys
import unittest
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from sentiment_engine import analyze_sentiment
from storage import SQLiteStorage, save_record_json, load_records_json, save_records_csv, load_records_csv
from analytics import calculate_metrics, search_records, paginate_records


class TestSentimentEngine(unittest.TestCase):
    def test_positive_unigram(self):
        res = analyze_sentiment("This product is amazing and clean.")
        self.assertEqual(res["label"], "Positive")
        self.assertGreater(res["score"], 0.2)
        self.assertIn("amazing", res["positive_words"])

    def test_negative_unigram(self):
        res = analyze_sentiment("The application is broken and slow.")
        self.assertEqual(res["label"], "Negative")
        self.assertLess(res["score"], -0.2)

    def test_negation_handling(self):
        # "not bad" should flip score towards positive or neutral
        res = analyze_sentiment("The support was not bad.")
        self.assertGreaterEqual(res["score"], -0.1)

    def test_bigram_detection(self):
        res = analyze_sentiment("This tool is a total disaster.")
        self.assertEqual(res["label"], "Negative")
        self.assertIn("total disaster", res["phrases_detected"])

    def test_intensifier_scaling(self):
        res_standard = analyze_sentiment("The UI is good.")
        res_intense = analyze_sentiment("The UI is extremely good.")
        self.assertGreater(res_intense["score"], res_standard["score"])

    def test_empty_string(self):
        res = analyze_sentiment("")
        self.assertEqual(res["score"], 0.0)
        self.assertEqual(res["label"], "Neutral")


class TestStorageEngine(unittest.TestCase):
    def setUp(self):
        self.test_dir = PROJECT_ROOT / "tests" / "temp_data"
        self.test_dir.mkdir(parents=True, exist_ok=True)
        self.json_file = self.test_dir / "test.json"
        self.csv_file = self.test_dir / "test.csv"
        self.db_file = self.test_dir / "test.db"

    def tearDown(self):
        for f in [self.json_file, self.csv_file, self.db_file]:
            if f.exists():
                try:
                    os.remove(f)
                except Exception:
                    pass

    def test_json_atomic_storage(self):
        rec = {"id": 1, "text": "Great test", "category": "Test", "score": 0.8, "label": "Positive", "confidence": 0.9, "timestamp": "2026-11-23"}
        success = save_record_json(rec, self.json_file)
        self.assertTrue(success)
        loaded = load_records_json(self.json_file)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["text"], "Great test")

    def test_sqlite_storage(self):
        db = SQLiteStorage(self.db_file)
        rec = {"id": 1, "text": "SQLite test record", "category": "Support", "score": -0.5, "label": "Negative", "confidence": 0.85, "timestamp": "2026-11-23"}
        self.assertTrue(db.save_record(rec))
        records = db.load_records()
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["label"], "Negative")


class TestAnalytics(unittest.TestCase):
    def test_pagination(self):
        records = [{"id": i, "text": f"Record {i}"} for i in range(1, 13)]
        page1, curr, total_pages = paginate_records(records, page=1, page_size=5)
        self.assertEqual(len(page1), 5)
        self.assertEqual(curr, 1)
        self.assertEqual(total_pages, 3)

        page3, curr3, total_pages3 = paginate_records(records, page=3, page_size=5)
        self.assertEqual(len(page3), 2)
        self.assertEqual(curr3, 3)

    def test_metrics_calculation(self):
        records = [
            {"score": 0.8, "label": "Positive", "category": "Review"},
            {"score": -0.6, "label": "Negative", "category": "Review"},
            {"score": 0.0, "label": "Neutral", "category": "Support"}
        ]
        metrics = calculate_metrics(records)
        self.assertEqual(metrics["total_records"], 3)
        self.assertEqual(metrics["positive_count"], 1)
        self.assertEqual(metrics["negative_count"], 1)
        self.assertEqual(metrics["neutral_count"], 1)


if __name__ == "__main__":
    unittest.main()
