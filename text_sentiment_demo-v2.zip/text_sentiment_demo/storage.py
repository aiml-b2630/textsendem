"""
Storage Module for Text Sentiment Demo
Supports Thread-Safe Dual JSON/CSV & SQLite Storage Engines with Atomic Writes.
"""

import csv
import json
import os
import sqlite3
import threading
from pathlib import Path
from typing import List, Dict, Any, Tuple
from logger import logger

DATA_DIR = Path(__file__).parent / "data"
JSON_FILE = DATA_DIR / "sentiment_records.json"
CSV_FILE = DATA_DIR / "sentiment_records.csv"
DB_FILE = DATA_DIR / "sentiment_records.db"

# Global Reentrant Lock for Thread-Safe File I/O
_FILE_LOCK = threading.RLock()


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


# =====================================================================
# Atomic Write Helper
# =====================================================================
def _atomic_write_text(filepath: Path, content: str):
    """Writes text to a temporary file before atomically replacing target."""
    _ensure_data_dir()
    temp_file = filepath.with_suffix(filepath.suffix + ".tmp")
    with open(temp_file, "w", encoding="utf-8") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp_file, filepath)


# =====================================================================
# SQLite Engine
# =====================================================================
class SQLiteStorage:
    def __init__(self, db_path: Path = DB_FILE):
        self.db_path = db_path
        _ensure_data_dir()
        self._init_db()

    def _get_connection(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with _FILE_LOCK:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS sentiment_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        text TEXT NOT NULL,
                        category TEXT NOT NULL,
                        score REAL NOT NULL,
                        label TEXT NOT NULL,
                        confidence REAL NOT NULL,
                        timestamp TEXT NOT NULL
                    )
                """)
                conn.commit()

    def save_record(self, record: Dict[str, Any]) -> bool:
        with _FILE_LOCK:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        INSERT INTO sentiment_records (id, text, category, score, label, confidence, timestamp)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        record.get("id"),
                        record.get("text"),
                        record.get("category"),
                        record.get("score"),
                        record.get("label"),
                        record.get("confidence"),
                        record.get("timestamp")
                    ))
                    conn.commit()
                logger.info(f"SQLite saved record ID {record.get('id')}")
                return True
            except Exception as e:
                logger.error(f"Failed to save record to SQLite: {e}")
                return False

    def load_records(self) -> List[Dict[str, Any]]:
        with _FILE_LOCK:
            try:
                with self._get_connection() as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM sentiment_records ORDER BY id ASC")
                    rows = cursor.fetchall()
                    return [dict(row) for row in rows]
            except Exception as e:
                logger.error(f"Failed to load records from SQLite: {e}")
                return []

    def bulk_insert(self, records: List[Dict[str, Any]]) -> bool:
        with _FILE_LOCK:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    for r in records:
                        cursor.execute("""
                            INSERT OR REPLACE INTO sentiment_records (id, text, category, score, label, confidence, timestamp)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        """, (
                            r.get("id"), r.get("text"), r.get("category"),
                            r.get("score"), r.get("label"), r.get("confidence"), r.get("timestamp")
                        ))
                    conn.commit()
                logger.info(f"SQLite bulk inserted {len(records)} records.")
                return True
            except Exception as e:
                logger.error(f"Failed SQLite bulk insert: {e}")
                return False


# =====================================================================
# Dual JSON & CSV Storage (Thread-Safe & Atomic)
# =====================================================================
def save_record_json(record: Dict[str, Any], filepath: Path = JSON_FILE) -> bool:
    with _FILE_LOCK:
        try:
            records = load_records_json(filepath)
            records.append(record)
            content = json.dumps(records, indent=2, ensure_ascii=False)
            _atomic_write_text(filepath, content)
            logger.info(f"JSON saved record ID {record.get('id')}")
            return True
        except Exception as e:
            logger.error(f"Failed to save JSON record: {e}")
            return False


def load_records_json(filepath: Path = JSON_FILE) -> List[Dict[str, Any]]:
    with _FILE_LOCK:
        if not filepath.exists():
            logger.info("JSON storage file missing. Initializing empty dataset.")
            return []
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.warning("JSON file corrupted! Returning empty list fallback.")
            return []
        except Exception as e:
            logger.error(f"Error loading JSON file: {e}")
            return []


def save_records_csv(records: List[Dict[str, Any]], filepath: Path = CSV_FILE) -> bool:
    with _FILE_LOCK:
        try:
            _ensure_data_dir()
            fieldnames = ["id", "text", "category", "score", "label", "confidence", "timestamp"]
            temp_file = filepath.with_suffix(".csv.tmp")
            
            with open(temp_file, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for r in records:
                    writer.writerow({k: r.get(k, "") for k in fieldnames})
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_file, filepath)
            logger.info(f"CSV saved {len(records)} records.")
            return True
        except Exception as e:
            logger.error(f"Failed to save CSV records: {e}")
            return False


def load_records_csv(filepath: Path = CSV_FILE) -> List[Dict[str, Any]]:
    with _FILE_LOCK:
        if not filepath.exists():
            logger.info("CSV storage file missing. Returning empty list.")
            return []
        try:
            records = []
            with open(filepath, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    records.append({
                        "id": int(row["id"]) if row.get("id") else 0,
                        "text": row.get("text", ""),
                        "category": row.get("category", "Uncategorized"),
                        "score": float(row.get("score", 0.0)),
                        "label": row.get("label", "Neutral"),
                        "confidence": float(row.get("confidence", 0.5)),
                        "timestamp": row.get("timestamp", "")
                    })
            return records
        except Exception as e:
            logger.error(f"Error loading CSV records: {e}")
            return []


# Unified Dual Save (Saves to both JSON & CSV + syncs SQLite)
def sync_all_storages(records: List[Dict[str, Any]]) -> bool:
    """Syncs a master dataset across JSON, CSV, and SQLite backends."""
    with _FILE_LOCK:
        success_json = save_record_json(records[-1]) if records else True
        success_csv = save_records_csv(records)
        sqlite_engine = SQLiteStorage()
        success_sqlite = sqlite_engine.bulk_insert(records)
        return success_json and success_csv and success_sqlite
