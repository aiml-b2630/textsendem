"""
Analytics and Visualization Module for Text Sentiment Demo.
Generates metrics aggregation, executive summary tables, Markdown reports, and Matplotlib trend charts.
"""

import os
from typing import List, Dict, Any

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def generate_metrics(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate summary statistics over text records."""
    if not records:
        return {
            "total_records": 0,
            "positive_count": 0,
            "neutral_count": 0,
            "negative_count": 0,
            "avg_score": 0.0,
            "positive_pct": 0.0,
            "negative_pct": 0.0,
            "neutral_pct": 0.0,
            "categories": {}
        }

    total = len(records)
    pos = sum(1 for r in records if r.get("sentiment_label") == "Positive")
    neu = sum(1 for r in records if r.get("sentiment_label") == "Neutral")
    neg = sum(1 for r in records if r.get("sentiment_label") == "Negative")
    
    scores = [float(r.get("sentiment_score", 0.0)) for r in records]
    avg_score = round(sum(scores) / total, 2)

    categories = {}
    for r in records:
        cat = r.get("category", "Uncategorized")
        categories[cat] = categories.get(cat, 0) + 1

    return {
        "total_records": total,
        "positive_count": pos,
        "neutral_count": neu,
        "negative_count": neg,
        "avg_score": avg_score,
        "positive_pct": round((pos / total) * 100, 1),
        "neutral_pct": round((neu / total) * 100, 1),
        "negative_pct": round((neg / total) * 100, 1),
        "categories": categories
    }

def print_summary_table(metrics: Dict[str, Any]):
    """Print clean terminal tabular summary."""
    print("\n" + "=" * 55)
    print("         EXECUTIVE SENTIMENT SUMMARY REPORT         ")
    print("=" * 55)
    print(f" Total Feedback Records Analyzed : {metrics['total_records']}")
    print(f" Average Sentiment Score        : {metrics['avg_score']:+.2f} (-1.0 to +1.0)")
    print("-" * 55)
    print(f" Positive Entries                : {metrics['positive_count']:<4} ({metrics['positive_pct']}%)")
    print(f" Neutral Entries                 : {metrics['neutral_count']:<4} ({metrics['neutral_pct']}%)")
    print(f" Negative Entries                : {metrics['negative_count']:<4} ({metrics['negative_pct']}%)")
    print("-" * 55)
    print(" Category Distribution:")
    for cat, count in metrics['categories'].items():
        print(f"   - {cat:<25} : {count} records")
    print("=" * 55 + "\n")

def export_markdown_report(metrics: Dict[str, Any], records: List[Dict[str, Any]], filename: str = "sentiment_summary_report.md") -> str:
    """Export multi-format executive summary report as Markdown."""
    content = f"""# Executive Sentiment Analysis Summary Report

## 1. Overview & Key Performance Indicators

- **Total Feedback Records Analyzed**: {metrics['total_records']}
- **Average Sentiment Index**: {metrics['avg_score']:+.2f}
- **Positive Sentiment Share**: {metrics['positive_pct']}% ({metrics['positive_count']} records)
- **Neutral Sentiment Share**: {metrics['neutral_pct']}% ({metrics['neutral_count']} records)
- **Negative Sentiment Share**: {metrics['negative_pct']}% ({metrics['negative_count']} records)

## 2. Category Breakdown

| Category | Record Count | Share (%) |
| :--- | :---: | :---: |
"""
    total = max(1, metrics['total_records'])
    for cat, count in metrics['categories'].items():
        pct = round((count / total) * 100, 1)
        content += f"| {cat} | {count} | {pct}% |\n"

    content += """
## 3. Sample Labeled Entries

| ID | Category | Sentiment | Score | Text Preview |
| :--- | :--- | :---: | :---: | :--- |
"""
    for r in records[:10]:
        preview = r.get("text", "")[:50] + ("..." if len(r.get("text", "")) > 50 else "")
        content += f"| {r.get('id')} | {r.get('category')} | {r.get('sentiment_label')} | {r.get('sentiment_score'):+.2f} | {preview} |\n"

    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content)

    return filename

def generate_sentiment_chart(records: List[Dict[str, Any]], output_image: str = "sentiment_distribution.png") -> str:
    """Generates visual Matplotlib charts showing sentiment distribution and score timeline."""
    if not records:
        return ""

    metrics = generate_metrics(records)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Text Sentiment Analysis Dashboard", fontsize=14, fontweight='bold')

    # Pie Chart - Sentiment Distribution
    labels = ['Positive', 'Neutral', 'Negative']
    counts = [metrics['positive_count'], metrics['neutral_count'], metrics['negative_count']]
    colors = ['#2ecc71', '#95a5a6', '#e74c3c']
    
    ax1.pie(counts, labels=labels, autopct='%1.1f%%', colors=colors, startangle=140, explode=(0.05, 0, 0.05))
    ax1.set_title("Overall Sentiment Breakdown")

    # Bar Chart - Category Breakdown
    cats = list(metrics['categories'].keys())
    cat_counts = list(metrics['categories'].values())

    ax2.barh(cats, cat_counts, color='#3498db')
    ax2.set_title("Records by Category")
    ax2.set_xlabel("Count")

    plt.tight_layout()
    plt.savefig(output_image, dpi=200)
    plt.close()

    return output_image
