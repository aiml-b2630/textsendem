"""
Sentiment Engine Module for Text Sentiment Demo.
Provides lexicon-based sentiment analysis, text sanitization, and score calculations.
"""

import re
from typing import Dict, Any, List

# Lexicon dictionary containing sentiment scores for key domain words
SENTIMENT_LEXICON: Dict[str, float] = {
    # Positive words
    "excellent": 1.0, "great": 0.8, "good": 0.6, "wonderful": 0.9, "outstanding": 1.0,
    "fantastic": 0.9, "amazing": 0.9, "positive": 0.7, "love": 0.8, "like": 0.5,
    "best": 0.9, "awesome": 0.8, "efficient": 0.7, "smooth": 0.6, "helpful": 0.7,
    "fast": 0.5, "innovative": 0.8, "robust": 0.7, "reliable": 0.7, "satisfied": 0.8,
    "delighted": 0.9, "impressive": 0.8, "clear": 0.5, "clean": 0.5, "success": 0.8,
    
    # Negative words
    "bad": -0.6, "poor": -0.7, "terrible": -0.9, "horrible": -0.9, "awful": -0.9,
    "slow": -0.5, "buggy": -0.8, "crash": -0.9, "broken": -0.8, "error": -0.7,
    "failed": -0.8, "frustrating": -0.8, "disappointed": -0.8, "difficult": -0.6,
    "expensive": -0.5, "confusing": -0.6, "useless": -0.9, "worst": -1.0, "issue": -0.5,
    "problem": -0.6, "delay": -0.6, "flaw": -0.7, "negative": -0.7, "hate": -0.8,
    
    # Intensifiers & Negations
    "very": 1.5, "extremely": 2.0, "highly": 1.5, "really": 1.3,
    "not": -1.0, "no": -1.0, "never": -1.0
}

def clean_text(text: str) -> str:
    """Sanitize and normalize raw input text."""
    if not text:
        return ""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.strip()

def analyze_sentiment(text: str) -> Dict[str, Any]:
    """
    Analyze the sentiment of a given text string.
    Returns score (-1.0 to +1.0), label (Positive/Neutral/Negative), and word metrics.
    """
    cleaned = clean_text(text)
    words = cleaned.split()
    
    if not words:
        return {
            "score": 0.0,
            "label": "Neutral",
            "confidence": 0.0,
            "positive_words": [],
            "negative_words": [],
            "word_count": 0
        }

    total_score = 0.0
    matched_words = 0
    pos_words = []
    neg_words = []
    multiplier = 1.0

    for i, word in enumerate(words):
        # Check negation in preceding word
        if i > 0 and words[i-1] in ["not", "no", "never"]:
            multiplier = -1.0
        else:
            multiplier = 1.0

        if word in SENTIMENT_LEXICON:
            val = SENTIMENT_LEXICON[word]
            if word in ["very", "extremely", "highly", "really", "not", "no", "never"]:
                continue
            
            score_contrib = val * multiplier
            total_score += score_contrib
            matched_words += 1
            
            if score_contrib > 0:
                pos_words.append(word)
            elif score_contrib < 0:
                neg_words.append(word)

    # Normalize score between -1.0 and +1.0
    if matched_words > 0:
        normalized_score = max(-1.0, min(1.0, total_score / max(1, matched_words)))
    else:
        normalized_score = 0.0

    # Determine Label
    if normalized_score >= 0.15:
        label = "Positive"
    elif normalized_score <= -0.15:
        label = "Negative"
    else:
        label = "Neutral"

    confidence = round(min(1.0, abs(normalized_score) + (matched_words * 0.1)), 2)

    return {
        "score": round(normalized_score, 2),
        "label": label,
        "confidence": confidence,
        "positive_words": pos_words,
        "negative_words": neg_words,
        "word_count": len(words)
    }
