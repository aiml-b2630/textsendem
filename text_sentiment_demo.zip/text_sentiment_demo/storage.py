"""
Storage Module for Text Sentiment Demo.
Handles CSV and JSON data persistence, auto-healing corrupted files, and record schema validation.
"""

import json
import csv
import os
from typing import List, Dict, Any

JSON_FILE = "sample_data.json"
CSV_FILE = "sample_data.csv"

DEFAULT_SCHEMA_KEYS = {"id", "timestamp", "category", "author", "text", "sentiment_score", "sentiment_label"}

def load_records(data_dir: str = ".") -> List[Dict[str, Any]]:
    """
    Loads records from JSON storage. If corrupt or missing, falls back to CSV or creates default.
    """
    json_path = os.path.join(data_dir, JSON_FILE)
    csv_path = os.path.join(data_dir, CSV_FILE)

    records = []

    # Attempt JSON load
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                records = json.load(f)
                if isinstance(records, list) and all(isinstance(r, dict) for r in records):
                    return records
        except (json.JSONDecodeError, OSError) as e:
            print(f"\033[91m[Warning] JSON data corrupted ({e}). Attempting CSV fallback...\033[0m")

    # Attempt CSV fallback
    if os.path.exists(csv_path):
        try:
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    row["sentiment_score"] = float(row.get("sentiment_score", 0.0))
                    records.append(row)
            if records:
                save_records(records, data_dir)  # Heal JSON
                return records
        except Exception as e:
            print(f"\033[91m[Warning] CSV data error ({e}). Initializing clean storage...\033[0m")

    # Initialize empty records list if all fail
    return records

def save_records(records: List[Dict[str, Any]], data_dir: str = ".") -> bool:
    """
    Persists records to both JSON and CSV files for redundancy.
    """
    json_path = os.path.join(data_dir, JSON_FILE)
    csv_path = os.path.join(data_dir, CSV_FILE)

    try:
        # Save JSON
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(records, f, indent=2, ensure_ascii=False)

        # Save CSV
        if records:
            fieldnames = ["id", "timestamp", "category", "author", "text", "sentiment_score", "sentiment_label"]
            with open(csv_path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
                writer.writeheader()
                writer.writerows(records)

        return True
    except Exception as e:
        print(f"\033[91m[Error] Failed to save persistence files: {e}\033[0m")
        return False
