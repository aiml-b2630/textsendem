# Text Sentiment Demo — Python Prototype Application

A modular, fault-tolerant Python software utility built for rapid local data sentiment analysis, input validation, structured persistence, and summary report generation.

---

## 🌟 Key Features

1. **Interactive CLI Menu Interface**: User-friendly navigation with ANSI color highlights and clear workflow options.
2. **Core Sentiment Engine**: Lexicon-backed scoring engine evaluating text strings for Positive, Negative, and Neutral labels with confidence indices.
3. **Defensive Input Validation**: Robust wrapper functions preventing invalid entries, blank inputs, or non-conforming parameters.
4. **Dual Data Persistence**: Automated JSON and CSV read/write routines with self-healing capabilities if storage files are missing or corrupted.
5. **Query & Record Filtering**: Keyword and sentiment label search tools across stored entries.
6. **Executive Summary Analytics**: Automated calculation of metrics, category distributions, average scores, and terminal tabular displays.
7. **Visual Plotting**: Matplotlib integration generating visual sentiment distribution pie charts and category bar plots.
8. **Multi-Format Export**: One-click generation of structured Markdown summary reports (`sentiment_summary_report.md`).

---

## 📁 Architecture & File Structure

```text
text_sentiment_demo/
├── main.py                     # Entry point & interactive CLI menu loop
├── sentiment_engine.py         # Core sentiment analysis & lexicon scoring engine
├── storage.py                  # Local CSV/JSON persistence & auto-healing module
├── analytics.py                # Aggregation metrics, tabular display, Matplotlib plotting, & Markdown report export
├── sample_data.json            # Seed dataset containing pre-loaded realistic test records
├── sample_data.csv             # CSV data storage format
├── README.md                   # Application documentation & setup guide
└── requirements.txt            # Package dependencies (matplotlib)
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Python 3.10+**
- **matplotlib** (for visual chart plotting)

### Installation & Execution

1. Extract `text_sentiment_demo.zip` to your local working folder.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python main.py
   ```

---

## 🧪 Hackathon Demo Scenario

1. Launch `python main.py` to see the welcome screen and main menu.
2. Select **[1]** to inspect the seed dataset records.
3. Select **[2]** to enter a new customer review or error log entry and view instant sentiment scoring.
4. Select **[4]** to display executive metrics and summary tables.
5. Select **[5]** to generate `sentiment_summary_report.md` and `sentiment_distribution.png`.
