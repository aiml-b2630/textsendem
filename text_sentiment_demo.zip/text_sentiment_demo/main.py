"""
Text Sentiment Demo - Main Application Entry Point
Interactive CLI menu interface with defensive validation, record search, data entry, and analytics.
"""

import sys
import os
import datetime
from typing import List, Dict, Any

from sentiment_engine import analyze_sentiment
from storage import load_records, save_records
from analytics import generate_metrics, print_summary_table, export_markdown_report, generate_sentiment_chart

# ANSI Color codes for clean CLI presentation
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def display_header():
    """Prints a styled welcome screen banner."""
    print(CYAN + BOLD + "=" * 60)
    print("        TEXT SENTIMENT DEMO — PYTHON APP PROTOTYPE        ")
    print("   AI & Smart Applications | Local Data Sentiment Utility ")
    print("=" * 60 + RESET)

def get_validated_input(prompt: str, options: List[str] = None) -> str:
    """Defensive input wrapper that prevents crashes on blank/invalid entries."""
    while True:
        try:
            val = input(prompt).strip()
            if not val:
                print(RED + "[Validation Error] Input cannot be blank. Please try again." + RESET)
                continue
            if options and val not in options:
                print(RED + f"[Validation Error] Invalid choice. Please choose from {options}." + RESET)
                continue
            return val
        except (KeyboardInterrupt, EOFError):
            print("\nExiting program input.")
            sys.exit(0)

def view_all_records(records: List[Dict[str, Any]]):
    """Display paginated/formatted table of stored records."""
    if not records:
        print(YELLOW + "\nNo records found in local storage." + RESET)
        return

    print(BOLD + f"\n--- STORED SENTIMENT RECORDS ({len(records)} total) ---" + RESET)
    print(f"{'ID':<6} | {'Category':<15} | {'Label':<10} | {'Score':<6} | {'Text Preview'}")
    print("-" * 65)
    for r in records[:15]:
        score_str = f"{r.get('sentiment_score', 0.0):+.2f}"
        lbl = r.get('sentiment_label', 'Neutral')
        color = GREEN if lbl == "Positive" else (RED if lbl == "Negative" else YELLOW)
        text_preview = r.get('text', '')[:28] + ("..." if len(r.get('text', '')) > 28 else "")
        print(f"{r.get('id'):<6} | {r.get('category'):<15} | {color}{lbl:<10}{RESET} | {score_str:<6} | {text_preview}")
    
    if len(records) > 15:
        print(YELLOW + f"... and {len(records) - 15} more records." + RESET)

def add_new_record(records: List[Dict[str, Any]], data_dir: str = "."):
    """Guided workflow for capturing and scoring a new text entry."""
    print(BOLD + "\n--- ADD NEW TEXT SENTIMENT RECORD ---" + RESET)
    author = get_validated_input("Enter author/user name: ")
    category = get_validated_input("Enter category (e.g., Product Review, Customer Support, Feedback, Docs): ")
    text = get_validated_input("Enter text content to analyze: ")

    analysis = analyze_sentiment(text)

    new_id = f"REC{len(records) + 1:03d}"
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    record = {
        "id": new_id,
        "timestamp": timestamp,
        "category": category,
        "author": author,
        "text": text,
        "sentiment_score": analysis["score"],
        "sentiment_label": analysis["label"],
        "confidence": analysis["confidence"]
    }

    records.append(record)
    save_records(records, data_dir)

    color = GREEN if analysis['label'] == "Positive" else (RED if analysis['label'] == "Negative" else YELLOW)
    print(GREEN + f"\n✓ Record {new_id} saved successfully!" + RESET)
    print(f"  Calculated Sentiment : {color}{analysis['label']}{RESET} (Score: {analysis['score']:+.2f}, Confidence: {analysis['confidence']})")

def search_records(records: List[Dict[str, Any]]):
    """Search and filter records by keyword or sentiment label."""
    if not records:
        print(YELLOW + "\nNo records available to search." + RESET)
        return

    query = get_validated_input("\nEnter keyword or sentiment label (Positive/Neutral/Negative) to search: ").lower()
    
    matches = []
    for r in records:
        if (query in r.get("text", "").lower() or
            query in r.get("category", "").lower() or
            query in r.get("sentiment_label", "").lower() or
            query in r.get("author", "").lower()):
            matches.append(r)

    print(BOLD + f"\n--- SEARCH RESULTS ({len(matches)} matching records) ---" + RESET)
    if not matches:
        print(YELLOW + "No matching records found." + RESET)
        return

    for r in matches:
        lbl = r.get("sentiment_label", "")
        color = GREEN if lbl == "Positive" else (RED if lbl == "Negative" else YELLOW)
        print(f"[{r.get('id')}] [{r.get('category')}] {color}{lbl}{RESET} ({r.get('sentiment_score'):+.2f}) - {r.get('text')}")

def main_loop(data_dir: str = "."):
    """Primary application navigation loop."""
    records = load_records(data_dir)

    while True:
        display_header()
        print(BOLD + "MAIN MENU OPTIONS:" + RESET)
        print(" [1] View Stored Sentiment Records")
        print(" [2] Add & Analyze New Text Entry")
        print(" [3] Search & Filter Records")
        print(" [4] Executive Summary & Analytics Table")
        print(" [5] Export Multi-Format Summary Report & Plot Chart")
        print(" [6] Exit Application")
        
        choice = get_validated_input("\nSelect an option [1-6]: ", ["1", "2", "3", "4", "5", "6"])

        if choice == "1":
            view_all_records(records)
        elif choice == "2":
            add_new_record(records, data_dir)
        elif choice == "3":
            search_records(records)
        elif choice == "4":
            metrics = generate_metrics(records)
            print_summary_table(metrics)
        elif choice == "5":
            metrics = generate_metrics(records)
            rpt = export_markdown_report(metrics, records, os.path.join(data_dir, "sentiment_summary_report.md"))
            chart = generate_sentiment_chart(records, os.path.join(data_dir, "sentiment_distribution.png"))
            print(GREEN + f"\n✓ Markdown Summary Report exported to: {rpt}" + RESET)
            print(GREEN + f"✓ Visual Sentiment Chart saved to: {chart}" + RESET)
        elif choice == "6":
            print(CYAN + "\nThank you for using Text Sentiment Demo. Goodbye!" + RESET)
            break

        input("\nPress Enter to return to main menu...")

if __name__ == "__main__":
    main_loop()
