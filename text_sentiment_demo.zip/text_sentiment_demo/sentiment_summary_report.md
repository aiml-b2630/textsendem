# Executive Sentiment Analysis Summary Report

## 1. Overview & Key Performance Indicators

- **Total Feedback Records Analyzed**: 20
- **Average Sentiment Index**: +0.10
- **Positive Sentiment Share**: 45.0% (9 records)
- **Neutral Sentiment Share**: 20.0% (4 records)
- **Negative Sentiment Share**: 35.0% (7 records)

## 2. Category Breakdown

| Category | Record Count | Share (%) |
| :--- | :---: | :---: |
| Product Review | 6 | 30.0% |
| Customer Support | 4 | 20.0% |
| Documentation | 2 | 10.0% |
| User Feedback | 5 | 25.0% |
| Error Logs | 3 | 15.0% |

## 3. Sample Labeled Entries

| ID | Category | Sentiment | Score | Text Preview |
| :--- | :--- | :---: | :---: | :--- |
| REC001 | Product Review | Positive | +0.85 | The new interface is extremely fast, clean, and in... |
| REC002 | Customer Support | Negative | -0.80 | Customer service was terrible and slow. The agent ... |
| REC003 | Documentation | Positive | +0.50 | The API documentation covers all required paramete... |
| REC004 | User Feedback | Neutral | +0.00 | System restarted at 12:00 PM for routine maintenan... |
| REC005 | Product Review | Positive | +0.82 | Wonderful execution! Highly reliable and efficient... |
| REC006 | Error Logs | Negative | -0.85 | Database connection timeout failed. Severe crash d... |
| REC007 | User Feedback | Negative | -0.30 | The app is not bad, but it can be expensive and so... |
| REC008 | Product Review | Positive | +0.80 | Fantastic analytics dashboard! The Matplotlib char... |
| REC009 | Customer Support | Positive | +0.75 | Support agent resolved my problem quickly. Very sa... |
| REC010 | User Feedback | Negative | -0.77 | Confusing workflow with frustrating UI glitches. I... |
